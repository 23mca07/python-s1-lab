import csv
with open("co53.csv","r") as csvfile:
   data=csv.reader(csvfile)
   for i in data:
      print(i)
