with open("bio.txt") as file:
    data = file.read()
    
print (data) 
