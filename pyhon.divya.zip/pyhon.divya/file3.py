with open("myfile.txt","w") as f:
     f.write("welcome to mits")
