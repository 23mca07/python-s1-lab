with open ("stud.txt")as file:
	slist=file.readlines()
print (slist)
slist=[x.strip() for x in slist]
print ("contents of file r")
print (slist)
	
	
