d1 = {'Anirudh': 10,'Yadu': 20, 'Divya': 30}
d2 = {'Aparna': 20,'Sherin': 40, 'Nayana': 50}
print("Merged dictionaries :",d1|d2)
