                    
str_1 =input("enter string:")

if str_1==str_1[::-1]

              print ("The string is a palindrome.")

else:

              print ("The string is not a palindrome.")

                
