 #2 Write a program to copy odd lines of one file to other.
#2 write a program to copy odd lines of the file stud.txt to odd.txt and copy the even lines of the file to even.txt

s=open("stud.txt","r")
o=open("odd.txt","w")
e=open("even.txt","w")
contents=s.readlines()
print("The contents of file are:")
print(contents)
for i in range(len(contents)):
  if(i%2==0):
     e.write(contents[i])
  else:
     o.write(contents[i])
s.close     
