print("GOOD MORNING.......")
