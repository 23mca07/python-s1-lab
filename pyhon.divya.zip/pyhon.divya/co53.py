#roll no,name,age#

30
divya
23
mca
s1
2023-2025
