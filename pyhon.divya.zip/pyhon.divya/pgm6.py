
s= [10,80,90,40,50,60]


k = 50

print("The list : " + str(s))

count = sum(i > k for i in s)

print("The numbers greater than 50 : " + str(count))

