f=open("bio.txt","r")
for x in f:
 print(x)
f.close() 
